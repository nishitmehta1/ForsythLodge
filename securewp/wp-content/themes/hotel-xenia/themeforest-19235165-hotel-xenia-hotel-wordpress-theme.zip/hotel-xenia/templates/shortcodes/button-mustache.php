<div class="plethora_button wpb_content_element {{ css }} {{ el_class }} {{ btn_align }} {{ button_inline }}">
    <a href="{{ btn_url }}" class="{{ btn_size }} {{ btn_style2 }} {{ btn_style }} {{ btn_with_icon }} {{ btn_icon_align }}" title="{{ btn_title }}"  target="{{ btn_target }}">

        {{# btn_icon_align_left }} <i class="{{ btn_icon }}"></i> {{/ btn_icon_align_left }}
        {{{ btn_text }}}
        {{# btn_icon_align_right }} <i class="{{ btn_icon }}"></i> {{/ btn_icon_align_right }}

    </a>
</div>