RESOURCES

• Windows Store
    • https://dev.windows.com/en-us/publish/windows-store-badges

• Amazon Store:     
    • https://developer.amazon.com/appsandservices/community/post/Tx1EHJ5ER3GUVMS/Amazon-Appstore-and-Kindle-Fire-Badges
    • https://developer.amazon.com/public/support/legal/tuabg

• Apple Store 
    • https://developer.apple.com/app-store/marketing/guidelines/#downloadOnAppstore
    • https://developer.apple.com/app-store/marketing/guidelines/#appstore

• Android (Google Play)
    • https://developer.android.com/distribute/tools/promote/badges.html