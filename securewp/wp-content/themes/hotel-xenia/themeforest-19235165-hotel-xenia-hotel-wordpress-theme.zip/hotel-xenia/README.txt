Theme Name: Hotel Xenia
Theme URI: http://plethorathemes.com/hotel-xenia/
Description: Hotel & Resort WordPress Theme 
Author: Plethora Themes
Author URI: http://www.plethorathemes.com

Features
--------

 - Minimal, Clean, Responsive Design
 - Fine typography and large photography
 - Subtle animations
 - Extensive Theme Options & Settings
 - Visual Composer with Custom Shortcodes
 - WooCommerce support
 - Revolution Slider support
 - The Events Calendar support
 - PinPoint Booking Calendar support
 - WPML ready